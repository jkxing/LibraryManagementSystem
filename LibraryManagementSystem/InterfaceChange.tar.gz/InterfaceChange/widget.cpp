#include "widget.h"
#include "ui_widget.h"
#include "one.h"
#include "two.h"
#include "three.h"
#include <QStackedLayout>
#include <QPushButton>
#include <QVBoxLayout>

Widget::Widget(QWidget *parent) :
    QWidget(parent)
{
    setFixedSize(400, 300);
    one = new One;
    two = new Two;
    three = new Three;
    stackLayout = new QStackedLayout;
    stackLayout->addWidget(one);
    stackLayout->addWidget(two); 
    stackLayout->addWidget(three);
    connect(one, &One::display, stackLayout, &QStackedLayout::setCurrentIndex);             // 0
    connect(two, &Two::display, stackLayout, &QStackedLayout::setCurrentIndex);             // 1
    connect(three, &Three::display, stackLayout, &QStackedLayout::setCurrentIndex);       // 2

    mainLayout = new QVBoxLayout;
    mainLayout->addLayout(stackLayout);
    setLayout(mainLayout);

}

Widget::~Widget()
{
}

