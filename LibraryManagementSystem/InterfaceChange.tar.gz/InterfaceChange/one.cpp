#include "one.h"
#include "ui_one.h"
#include "two.h"
#include "widget.h"

One::One(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::One)
{
    ui->setupUi(this);

}

One::~One()
{
    delete ui;
}

void One::on_nextPushButton_clicked()
{
    emit display(1);
}
