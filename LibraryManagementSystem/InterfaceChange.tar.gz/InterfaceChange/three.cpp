#include "three.h"
#include "ui_three.h"

Three::Three(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Three)
{
    ui->setupUi(this);
}

Three::~Three()
{
    delete ui;
}

void Three::on_previousPushButton_clicked()
{
    emit display(1);
}
