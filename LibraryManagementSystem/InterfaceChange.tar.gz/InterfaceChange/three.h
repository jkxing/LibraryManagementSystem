#ifndef THREE_H
#define THREE_H

#include <QWidget>

namespace Ui {
class Three;
}

class Three : public QWidget
{
    Q_OBJECT

public:
    explicit Three(QWidget *parent = 0);
    ~Three();

signals:
    void display(int number);

private slots:
    void on_previousPushButton_clicked();

private:
    Ui::Three *ui;
};

#endif // THREE_H
