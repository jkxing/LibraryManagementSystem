#include "two.h"
#include "ui_two.h"

Two::Two(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Two)
{
    ui->setupUi(this);
}

Two::~Two()
{
    delete ui;
}

void Two::on_previousPushButton_clicked()
{
    emit display(0);
}

void Two::on_nextPushButton_clicked()
{
    emit display(2);
}
