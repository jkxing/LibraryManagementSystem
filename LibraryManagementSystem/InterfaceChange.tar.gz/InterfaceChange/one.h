#ifndef ONE_H
#define ONE_H

#include <QWidget>

class Two;

namespace Ui {
class One;
}

class One : public QWidget
{
    Q_OBJECT

public:
    explicit One(QWidget *parent = 0);
    ~One();

signals:
    void display(int number);

private slots:
    void on_nextPushButton_clicked();

private:
    Ui::One *ui;
    Two *two;
};

#endif // ONE_H
