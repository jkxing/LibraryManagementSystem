#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

class One;
class Two;
class Three;
class QStackedLayout;
class QVBoxLayout;

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private:
    One *one;
    Two *two;
    Three *three;
    QStackedLayout *stackLayout;
    QVBoxLayout *mainLayout;
};

#endif // WIDGET_H
